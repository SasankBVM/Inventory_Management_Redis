<!DOCTYPE html>   
<html>   
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<title> Login Page </title>  
<style>   
Body {  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
button {   
       background-color: #4CAF50;   
       width: 100%;  
        color: orange;   
        padding: 15px;   
        margin: 10px 0px;   
        border: none;   
        cursor: pointer;   
         }   
 form {   
        border: 3px solid #f1f1f1;   
    }   
 input[type=text], input[type=password] {   
        width: 100%;   
        margin: 8px 0;  
        padding: 12px 20px;   
        display: inline-block;   
        border: 2px solid green;   
        box-sizing: border-box;   
    }  
 button:hover {   
        opacity: 0.7;   
    }   
  .cancelbtn {   
        width: auto;   
        padding: 10px 18px;  
        margin: 10px 5px;  
    }   
        
     
 .container {   
        padding: 25px;   
        background-color: lightblue;  
    }   
</style>   
</head>    
<body>    
    <center> <h1> VENDOR LOGIN FORM </h1> </center>   
    <form action="../redis/vendor_page.php" method="POST">  
        <div class="container">   
            <label>USERID : </label>   
            <input type="text" placeholder="ENTER USERID" name="uname" required>  
            <label>Password : </label>   
            <input type="password" placeholder="ENTER PASSWORD" name="pwd" required>  
            <button type="submit">LOGIN</button>        
            <p style="text-align: center;"><button type="button" class="cancelbtn"><a href="../view/vendor_login.php">CANCEL</a></button></p>
      <h3 style="text-align: center; border-right: 10px;">Don't have an account yet?</h3>
      <a style="text-align: center;" href="../view/vendor_registration.php"><p style="text-align: center;">CLICK HERE TO REGISTER</p></a></span>  
      <!-- <a style="text-align: center;" href="../view/vendor_registration.php"><p style="text-align: center;">HOME </p></a></span>   -->
        </div>   
    </form>     
</body>     
</html>  