<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
.container {  
    padding: 50px;  
  background-color: lightblue;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: cyan;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 1   ;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body>  
<form action="../redis/purchase.php" method="POST">  
  <div class="container">  
  <center>  <h1>PURCHASE ITEMS</h1> </center>  
  <hr>  
  <label><b> NAME </b></label>   
<input type="text" name="cust_name" placeholder= "Enter your name" size="15" required />        
<div>  
<label>  
</div>  
<label>   
<b>PHONE </b>  
</label>  
<!-- <input type="text" name="country code" placeholder="Country Code"  value="+91 " size="2"/>    -->
<input type="text" name="cust_contact" placeholder="phone no." size="10"/ required>     
 <label for="email"><b>EMAIL</b></label>  
 <input type="text" placeholder="Enter Email" name="cust_email" required> 
 <div> 
     <div>
    <label>   
        <b>SELECT ITEM:</b>
        <br>  
        <br>
        </label>     
        <select name="item_1"> 
        <option value="none">none</option>  
        <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
        <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
        <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
        <option value="GREEN TEA">GREEN TEA</option>  
        <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
        <option value="DABUR HONEY">DABUR HONEY</option>  
        <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
        <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
        <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
        <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
        </select>
        <select name="quan_1"> 
            <option value="0">0</option>  
            <option value="1">1</option>  
            <option value="2">2</option>  
            <option value="3">3</option>  
            <option value="4">4</option>  
            <option value="5">5</option>  
            <option value="6">6</option>  
            <option value="7">7</option> 
            <option value="8">8</option> 
            <option value="9">9</option> 
            <option value="10">10</option> 
            </select>     
        <br>
        <br>
    </div>
    <div>
        <label>   
            <b>SELECT ITEM:</b>
            <br>  
            <br>
            </label>     
            <select name="item_2"> 
            <option value="none">none</option>  
            <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
            <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
            <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
            <option value="GREEN TEA">GREEN TEA</option>  
            <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
            <option value="DABUR HONEY">DABUR HONEY</option>  
            <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
            <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
            <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
            <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
            </select>
            <select name="quan_2"> 
                <option value="0">0</option>  
                <option value="1">1</option>  
                <option value="2">2</option>  
                <option value="3">3</option>  
                <option value="4">4</option>  
                <option value="5">5</option>  
                <option value="6">6</option>  
                <option value="7">7</option> 
                <option value="8">8</option> 
                <option value="9">9</option> 
                <option value="10">10</option> 
                </select>     
            <br>
            <br>
        </div>
        <div>
            <label>   
                <b>SELECT ITEM:</b>
                <br>  
                <br>
                </label>     
                <select name="item_3"> 
                <option value="none">none</option>  
                <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                <option value="GREEN TEA">GREEN TEA</option>  
                <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                <option value="DABUR HONEY">DABUR HONEY</option>  
                <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                </select>
                <select name="quan_3"> 
                    <option value="0">0</option>  
                    <option value="1">1</option>  
                    <option value="2">2</option>  
                    <option value="3">3</option>  
                    <option value="4">4</option>  
                    <option value="5">5</option>  
                    <option value="6">6</option>  
                    <option value="7">7</option> 
                    <option value="8">8</option> 
                    <option value="9">9</option> 
                    <option value="10">10</option> 
                    </select>     
                <br>
                <br>
            </div>
            <div>
                <label>   
                    <b>SELECT ITEM:</b>
                    <br>  
                    <br>
                    </label>     
                    <select name="item_4"> 
                    <option value="none">none</option>  
                    <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                    <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                    <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                    <option value="GREEN TEA">GREEN TEA</option>  
                    <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                    <option value="DABUR HONEY">DABUR HONEY</option>  
                    <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                    <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                    <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                    <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                    </select>
                    <select name="quan_4"> 
                        <option value="0">0</option>  
                        <option value="1">1</option>  
                        <option value="2">2</option>  
                        <option value="3">3</option>  
                        <option value="4">4</option>  
                        <option value="5">5</option>  
                        <option value="6">6</option>  
                        <option value="7">7</option> 
                        <option value="8">8</option> 
                        <option value="9">9</option> 
                        <option value="10">10</option> 
                        </select>     
                    <br>
                    <br>
                </div>
                <div>
                    <label>   
                        <b>SELECT ITEM:</b>
                        <br>  
                        <br>
                        </label>     
                        <select name="item_5"> 
                        <option value="none">none</option>  
                        <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                        <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                        <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                        <option value="GREEN TEA">GREEN TEA</option>  
                        <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                        <option value="DABUR HONEY">DABUR HONEY</option>  
                        <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                        <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                        <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                        <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                        </select>
                        <select name="quan_5"> 
                            <option value="0">0</option>  
                            <option value="1">1</option>  
                            <option value="2">2</option>  
                            <option value="3">3</option>  
                            <option value="4">4</option>  
                            <option value="5">5</option>  
                            <option value="6">6</option>  
                            <option value="7">7</option> 
                            <option value="8">8</option> 
                            <option value="9">9</option> 
                            <option value="10">10</option> 
                            </select>     
                        <br>
                        <br>
                    </div>
                    <div>
                        <label>   
                            <b>SELECT ITEM:</b>
                            <br>  
                            <br>
                            </label>     
                            <select name="item_6"> 
                            <option value="none">none</option>  
                            <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                            <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                            <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                            <option value="GREEN TEA">GREEN TEA</option>  
                            <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                            <option value="DABUR HONEY">DABUR HONEY</option>  
                            <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                            <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                            <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                            <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                            </select>
                            <select name="quan_6"> 
                                <option value="0">0</option>  
                                <option value="1">1</option>  
                                <option value="2">2</option>  
                                <option value="3">3</option>  
                                <option value="4">4</option>  
                                <option value="5">5</option>  
                                <option value="6">6</option>  
                                <option value="7">7</option> 
                                <option value="8">8</option> 
                                <option value="9">9</option> 
                                <option value="10">10</option> 
                                </select>     
                            <br>
                            <br>
                        </div>
                        <div>
                            <label>   
                                <b>SELECT ITEM:</b>
                                <br>  
                                <br>
                                </label>     
                                <select name="item_7"> 
                                <option value="none">none</option>  
                                <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                                <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                                <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                                <option value="GREEN TEA">GREEN TEA</option>  
                                <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                                <option value="DABUR HONEY">DABUR HONEY</option>  
                                <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                                <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                                <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                                <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                                </select>
                                <select name="quan_7"> 
                                    <option value="0">0</option>  
                                    <option value="1">1</option>  
                                    <option value="2">2</option>  
                                    <option value="3">3</option>  
                                    <option value="4">4</option>  
                                    <option value="5">5</option>  
                                    <option value="6">6</option>  
                                    <option value="7">7</option> 
                                    <option value="8">8</option> 
                                    <option value="9">9</option> 
                                    <option value="10">10</option> 
                                    </select>     
                                <br>
                                <br>
                            </div>
                            <div>
                                <label>   
                                    <b>SELECT ITEM:</b>
                                    <br>  
                                    <br>
                                    </label>     
                                    <select name="item_8"> 
                                    <option value="none">none</option>  
                                    <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                                    <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                                    <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                                    <option value="GREEN TEA">GREEN TEA</option>  
                                    <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                                    <option value="DABUR HONEY">DABUR HONEY</option>  
                                    <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                                    <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                                    <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                                    <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                                    </select>
                                    <select name="quan_8"> 
                                        <option value="0">0</option>  
                                        <option value="1">1</option>  
                                        <option value="2">2</option>  
                                        <option value="3">3</option>  
                                        <option value="4">4</option>  
                                        <option value="5">5</option>  
                                        <option value="6">6</option>  
                                        <option value="7">7</option> 
                                        <option value="8">8</option> 
                                        <option value="9">9</option> 
                                        <option value="10">10</option> 
                                        </select>     
                                    <br>
                                    <br>
                                </div>
                                <div>
                                    <label>   
                                        <b>SELECT ITEM:</b>
                                        <br>  
                                        <br>
                                        </label>     
                                        <select name="item_9"> 
                                        <option value="none">none</option>  
                                        <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                                        <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                                        <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                                        <option value="GREEN TEA">GREEN TEA</option>  
                                        <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                                        <option value="DABUR HONEY">DABUR HONEY</option>  
                                        <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                                        <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                                        <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                                        <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                                        </select>
                                        <select name="quan_9"> 
                                            <option value="0">0</option>  
                                            <option value="1">1</option>  
                                            <option value="2">2</option>  
                                            <option value="3">3</option>  
                                            <option value="4">4</option>  
                                            <option value="5">5</option>  
                                            <option value="6">6</option>  
                                            <option value="7">7</option> 
                                            <option value="8">8</option> 
                                            <option value="9">9</option> 
                                            <option value="10">10</option> 
                                            </select>     
                                        <br>
                                        <br>
                                    </div>
                                    <div>
                                        <label>   
                                            <b>SELECT ITEM:</b>
                                            <br>  
                                            <br>
                                            </label>     
                                            <select name="item_10"> 
                                            <option value="none">none</option>  
                                            <option value="ALOE VERA GEL">ALOE VERA GEL</option>  
                                            <option value="NIVEA BODY LOTION">NIVEA BODY LOTION</option>  
                                            <option value="NIVEA MOISTURIZER">NIVEA MOISTURIZER</option>  
                                            <option value="GREEN TEA">GREEN TEA</option>  
                                            <option value="SAVLON HAND WASH">SAVLON HAND WASH</option>  
                                            <option value="DABUR HONEY">DABUR HONEY</option>  
                                            <option value="LAKME SUN SCREEN LOTION">LAKME SUN SCREEN LOTION</option> 
                                            <option value="COLGATE TOOTH PASTE">COLGATE TOOTH PASTE</option> 
                                            <option value="HORLICKS PROTEIN PLUS">HORLICKS PROTEIN PLUS</option> 
                                            <option value="PARLIE HIDE AND SEEK BISCUITS">PARLIE HIDE AND SEEK BISCUITS</option> 
                                            </select>
                                            <select name="quan_10"> 
                                                <option value="0">0</option>  
                                                <option value="1">1</option>  
                                                <option value="2">2</option>  
                                                <option value="3">3</option>  
                                                <option value="4">4</option>  
                                                <option value="5">5</option>  
                                                <option value="6">6</option>  
                                                <option value="7">7</option> 
                                                <option value="8">8</option> 
                                                <option value="9">9</option> 
                                                <option value="10">10</option> 
                                                </select>     
                                            <br>
                                            <br>
                                        </div>
<label>   
<b>SELECT VENDOR OF YOUR CONVINIENCE:</b>
<br>  
<br>
</label>   

<select name="cust_vendor"> 
<option value="none">none</option>  
<option value="AMIT THAKUR">AMIT THAKUR</option>  
<option value="BHAJARANG LAL">BHAJARANG LAL</option>  
<option value="MURUGAN">MURUGAN</option>  
<option value="RAMESH SHETTY">RAMESH SHETTY</option>  
<option value="INDRA SENA REDDY">INDRA SENA REDDY</option>  
<option value="SHYAM SINGHA ROY">SHYAM SINGHA ROY</option>  
<option value="KABIR SHAW">KABIR SHAW</option> 
<option value="RAJIV YADAV">RAJIV YADAV</option> 
<option value="BHAVYA SHARMA">BHAVYA SHARMA</option> 
<option value="RAGHUVEER SINGH">RAGHUVEER SINGH</option> 
</select>  
</div>   

    <button type="submit" class="registerbtn"><b>SUBMIT</b></button>    
</form>  
</body>  
</html>  