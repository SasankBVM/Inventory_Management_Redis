
<div class="footer">
    <p style="text-align: center;">All rights reserved @<a href="">INVENTORY MANAGEMENT</a></p>
</div>