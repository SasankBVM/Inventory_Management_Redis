<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
.container {  
    padding: 50px;  
  background-color: lightblue;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: cyan;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 1   ;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body>  
<form action="../redis/vendor_reg.php" method="POST">  
  <div class="container">  
  <center>  <h1>VENDOR_REGSITRATION</h1> </center>  
  <hr>  
  <label> Firstname </label>   
<input type="text" name="firstname" placeholder= "Firstname" id="firstname" size="15" required />     
<label> Lastname: </label>    
<input type="text" name="lastname" placeholder="Lastname" id="lastname" size="15"required />   
<div>  
<label>   
Gender :  
</label><br>  
<input type="radio" value="Male" name="gender" id="gender" checked > Male   
<input type="radio" value="Female" name="gender" id="gender"> Female   
<!-- <input type="radio" value="Other" name="gender"> Other   -->
</div>  
<label>   
Phone :  
</label>  
<input type="text" name="vend_contact" placeholder="Contact" id="vend_contact" size="10"/>   
<!-- <input type="text" name="phone" placeholder="phone no." size="10"/ required>    -->
Current Address :  
<textarea cols="80" name="vend_address" rows="5" placeholder="Current Address" value="vend_address" id="vend_address" required>  
</textarea>  
 <label for="email"><b>Email</b></label>  
 <input type="text" placeholder="Enter Email" name="vend_email" id="vend_email" required>  
  
    <label for="psw"><b>Password</b></label>  
    <input type="password" placeholder="Enter Password" name="vend_pwd" id="vend_pwd" required>  
  
    <label for="psw-repeat"><b>Re-type Password</b></label>  
    <input type="password" placeholder="Retype Password" name="vend_rpwd" id="vend_rpwd" required>  
    <button type="submit" class="registerbtn">REGISTER</button>
    <h3 style="text-align: center; border-right: 10px;">ALREADY HAD AN ACCOUNT? </h3>
    <a style="text-align: center;" href="../view/vendor_login.php"><p style="text-align: center;">SIGN IN</p></a></span>      
</form>  
</body>  
</html>  