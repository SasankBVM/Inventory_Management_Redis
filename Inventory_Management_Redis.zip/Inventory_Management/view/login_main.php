<?php  
	$login_id = $_POST['uname']; 
	$pwd = $_POST['psw']; 
	
	if($login_id=="abcde" && $pwd="12345"){ 
		echo '<html>
				<head>  
					<style> 
						
						body{ 
							background-color:yellow; 
							}
						table{ 
							width:40%; 
							margin:auto; 
							margin-top:8%; 
							}
						table td { 
							background-color:black; 
							color:white; 
							padding:20px; 
							} 
						table td a{ 
							text-decoration:none; 
							color:white; 
							} 
						table a:hover{ 
							color:green; 
							font-size:120%; 
							} 
						h2{ 
							margin-top:10%; 
							}
							
					</style>
				</head> 
				
				<body> 
				  <div class="box">
          <h1 style="text-align=center;"> WELCOME $login_id</h1>
					<center><h2>DASH BOARD</h2></center>
				  <table> 
					<tr>
						<td><a href="redis/full_names.php"> VIEW ALL PASSNGERS </a></td> 
						<td><a href="redis/all_keys.php"> VIEW AADHAR NUMBERS OF PASSENGERS </a> </td>
					</tr>
				  </table>
				  </div>
				</body>
			  </html>
			  ';
		} 
	else{ 
		echo ' Invalid Login Credentials '; 
		}
	
?> 
