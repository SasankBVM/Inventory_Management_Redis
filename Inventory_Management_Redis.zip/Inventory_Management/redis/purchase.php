<?php
require '../redis/predis/src/Autoloader.php';
Predis\Autoloader::register();
$client = new Predis\Client([
    'scheme'=>'tcp', 
    'host'=>'127.0.0.1', 
    'port'=>6379, 
    ]); 
    $cust_name=$_POST['cust_name'];
    $cust_contact=$_POST['cust_contact'];
    $cust_email=$_POST['cust_email'];
    //list of items
    $cust_item_1=$_POST['item_1'];
    $cust_item_quan_1=$_POST['quan_1'];
    $item_1_bp=80;
    $cust_item_2=$_POST['item_2'];
    $cust_item_quan_2=$_POST['quan_2'];
    $item_2_bp=186;
    $cust_item_3=$_POST['item_3'];
    $cust_item_quan_3=$_POST['quan_3'];
    $item_3_bp=200;
    $cust_item_4=$_POST['item_4'];
    $cust_item_quan_4=$_POST['quan_4'];
    $item_4_bp=80;
    $cust_item_5=$_POST['item_5'];
    $cust_item_quan_5=$_POST['quan_5'];
    $item_5_bp=90;
    $cust_item_6=$_POST['item_6'];
    $cust_item_quan_6=$_POST['quan_6'];
    $item_6_bp=200;
    $cust_item_7=$_POST['item_7'];
    $cust_item_quan_7=$_POST['quan_7'];
    $item_7_bp=280;
    $cust_item_8=$_POST['item_8'];
    $cust_item_quan_8=$_POST['quan_8'];
    $item_8_bp=80;
    $cust_item_9=$_POST['item_9'];
    $cust_item_quan_9=$_POST['quan_9'];
    $item_9_bp=240;
    $cust_item_10=$_POST['item_10'];
    $cust_item_quan_10=$_POST['quan_10'];
    $item_10_bp=40;
    $cust_vendor=$_POST['cust_vendor'];
    $total=$item_1_bp*$cust_item_quan_1+$item_2_bp*$cust_item_quan_2+$item_3_bp*$cust_item_quan_3+$item_4_bp*$cust_item_quan_4+$item_5_bp*$cust_item_quan_5+$item_6_bp*$cust_item_quan_6+$item_7_bp*$cust_item_quan_7+$item_8_bp*$cust_item_quan_8+$item_9_bp*$cust_item_quan_9+$item_10_bp*$cust_item_quan_10;
    //DISPLAYING CONTENT

    echo '
    <style>
    .button {
        transition-duration: 0.4s;
        width:250px;
      }
      
      .button:hover {
        background-color: cyan; 
        color: blue;
        border-color: orange;
      }
    </style>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=10" >

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/product.css">
    <link rel="stylesheet" type="text/css" href="../css/navigation.css">
    <title>ITEMS</title>
        </head>
<body>';
echo '<h1 style="text-align: center;color: red;">WELCOME:';
echo "$cust_name";
echo '<h1 style="text-align: center;color: black;">ORDER CONFORMATION';
echo '
<h1 style="text-align: center;color: darkorange;">VENDOR NAME:';
echo "$cust_vendor";
echo '<h1 style="text-align: center;color: red;">TOTAL AMOUNT:';
echo '₹';
echo "$total";
echo '</h1>
<div class="row" style="padding: 40px;">
    <div class="leftcolumn">
        <div class="card">
            <div class="table_container">
                <div class="table-responsive">
                    <table class="table table-dark" id="table" data-toggle="table" data-search="true" data-filter-control="true" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                        <thead class="thead-light">
                            <tr>
                                <th data-field="date" data-filter-control="select" data-sortable="true">S.NO</th>
                                <th data-field="note" data-filter-control="select" data-sortable="true">ITEM_NAME</th>
                                <th data-field="examen" data-filter-control="select" data-sortable="true">ITEM_QUANTITY</th>
                            </tr>
                        </thead>
                        <tbody>';

                        echo "<tr>
                            <big><td>1</td></big>
                            <td>$cust_item_1</td>
                            <td>$cust_item_quan_1</td>
                        </tr>";
                        echo "<tr>
                            <big><td>2</td></big>
                            <td>$cust_item_2</td>
                            <td>$cust_item_quan_2</td>
                            </tr>";
                            echo "<tr>
                            <big><td>3</td></big>
                            <td>$cust_item_3</td>
                            <td>$cust_item_quan_3</td>
                        
                        </tr>";
                        echo "<tr>
                            <big><td>4</td></big>
                            <td>$cust_item_4</td>
                            <td>$cust_item_quan_4</td>
                            
                            
                        </tr>";
                        echo "<tr>
                            <big><td>5</td></big>
                            <td>$cust_item_5</td>
                            <td>$cust_item_quan_5</td>
                            
            
                        </tr>";
                        echo "<tr>
                            <big><td>6</td></big>
                            <td>$cust_item_6</td>
                            <td>$cust_item_quan_6</td>
                            
                        </tr>";

                        echo "<tr>
                            <big><td>7</td></big>
                            <td>$cust_item_7</td>
                            <td>$cust_item_quan_7</td>
                                          
                        </tr>";
                        echo "<tr>
                            <big><td>8</td></big>
                            <td>$cust_item_8</td>
                            <td>$cust_item_quan_8</td>
                                                 
                        </tr>";
                        echo "<tr>
                            <big><td>9</td></big>
                            <td>$cust_item_9</td>
                            <td>$cust_item_quan_9</td>
                               
                        </td>
                        </tr>";
                        echo "<tr>
                            <big><td>10</td></big>
                            <td>$cust_item_10</td>
                            <td>$cust_item_quan_10</td>
                            
                            </tr>";
                            echo "</tbody>
                    </table>
                </div>
                <form action='../view/purchase_conf.php' method=POST>
                <p style='text-align:center;'><button type='submit' class='button'> SUBMIT</button></p>
                </form>
                
            </div>
        </div>
    </div>
</div>
</body>
</html>";               
?>  