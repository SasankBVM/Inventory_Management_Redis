<?php 
	require '../redis/predis/src/Autoloader.php';
    Predis\Autoloader::register();
	$client = new Predis\Client([
		'scheme'=>'tcp', 
		'host'=>'127.0.0.1', 
		'port'=>6379, 
		]); 

    $vend_first_name = $_POST['firstname'];
    $vend_last_name = $_POST['lastname']; 
	$vend_gender=$_POST['gender'];
	$vend_cont = $_POST['vend_contact']; 
	$vend_address=$_POST['vend_address'];
	$vend_email = $_POST['vend_email'];
    $vend_pwd=$_POST['vend_pwd'];
    $vend_rpwd=$_POST['vend_rpwd'];
	$vend_name=$vend_first_name." ".$vend_last_name;
	$key = "vend_names:".$vend_cont; 
        if($vend_pwd!=$vend_rpwd)
        {
            echo '<html>  
		    <head> 
				<style> 
					body{ 
					background-color:cyan; 
					 
					padding:200px; 
					}
				</style>
			</head>
            <body><h1>PASSWORDS DID NOT MATCH </h1></body>
            <br>
            <a href="../view/vendor_registration.php">CLICK HERE TO RE-REGISTER></a>
		</html>';
        }
        else{
    $client->set($key.":vend_name",$vend_name) ; 	 
	$client->set($key.":vend_cont",$vend_cont) ; 
	$client->set($key.":vend_email",$vend_email) ;
	$client->set($key.":vend_address",$vend_address);
	$client->set($key.":vend_pwd",$vend_pwd) ; 
	//$client->rpush("passengers",$aadhar);  
    $client->sAdd("vend_names",$vend_name,'1');   
	echo ' <script> 
	    alert(" Congrats !! YOU HAVE GOT REGISTERED SUCCESFULLY") ; 
    </script>';	
    // echo "Connection to server sucessfully"; 
   //check whether server is running or not 
   echo '
			<style>
			h1 {
				width:500px;
				margin: 0 auto;
				background: cyan;
				text-color:red;
				text-align: center;
			}
			</style>
   		<html>  
		    <head> 
				<style> 
					body{ 
					background-color:yellow; 
					 
					padding:200px; 
					}
				</style>
			</head>
		</html>' ;
   echo "<h1> Dear ".$vend_name." YOUR ID IS ".$key ." </h1>";
   echo "<br>"; 
   echo '<a href="../view/vendor_login.php"> <p style="text-align: center;">CLICK HERE TO LOGIN</p> </a> ';
        }   
?>