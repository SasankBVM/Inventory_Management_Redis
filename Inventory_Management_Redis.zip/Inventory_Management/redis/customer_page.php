<?php
require '../redis/predis/src/Autoloader.php';
Predis\Autoloader::register();
$client = new Predis\Client([
    'scheme'=>'tcp', 
    'host'=>'127.0.0.1', 
    'port'=>6379, 
    ]); 
    $cust_name=$_POST['uname'];
    $cust_pwd=$_POST['psw'];
    
    $key = "cust_names:".$cust_name.":cust_cont";
    $id=$client->get($key);
    $password="cust_names:".$cust_name.":cust_pwd";
    $pwd=$client->get($password);
    $name_key="cust_names:".$cust_name.":cust_name";
    $cust_fname=$client->get($name_key);
    if(($cust_name==$id)&&($cust_pwd==$pwd))
    {
        echo '
            <style>
    form {
  border: 3px solid #f1f1f1;
}
/* Full-width inputs */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: cyan;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}

/* Extra style for the cancel button (red) */
.cancelbtn {
  text-align: center;
  width: auto;
  margin-left: 520px;
  padding: 10px 18px;
  background-color: burlywood;
}
/* Center the avatar image inside this container */
.imgcontainer {
  text-align: center;
  height: 1px;
  width: 20px;
}

/* Avatar image */
img.avatar {
  width: 20%;
  border-radius: 50%;
}

/* Add padding to containers */
.container {
  padding: 16px;
}

/* The "Forgot password" text */
span.psw {
  float: right;
  padding-top: 16px;
}
.imgcontainer {
  background-image: url("img2.png");
  /* background-size: cover; */
  border-radius: 30%;
  width: 5px;
  height: 1px;
  margin-left: 100px;
  margin-right: 5px;
  padding-left: 20px;
  padding-right: 20px;
  border: solid 5px red;
}
/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
    display: block;
    float: none;
  }
  .cancelbtn {
    width: 100%;
  }
}
.btn {
  border: none;
  outline: none;
  padding: 10px 16px;
  background-color: #f1f1f1;
  cursor: pointer;
}

/* Style the active class (and buttons on mouse-over) */
.active, .btn:hover {
  background-color:darkmagenta;
  color: white;
}
</style>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Inventory Management</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
    <a class="navbar-brand" href="../view/login.php"><p style="text-align: center;">INVENTORY MANAGEMENT</p></a>
    </div>
    <ul class="nav navbar-nav">
      <!-- <li class="active"><a href="#">Home</a></li> -->
      <li><a href="#">HOME</a></li>
      <li><a href="../view/item.html">ITEM SEARCH</a></li>
      <li><a href="../view/vendor_details.html">VENDOR DETAILS</a></li>
      <li><a href="../view/purchase.php">PURCHASE ITEM</a></li>
      <li><a href="../view/login.php">LOG OUT</a></li>
    </ul>
  </div>
</nav>
<h1 style="text-align: center; color: darkgoldenrod;">WELCOME TO INVENTORY MANAGEMENT</h1>
<br>';
echo'
<h1 style="text-align: center; color: darkgoldenrod;">WELCOME DEAR ';
echo $cust_fname;
echo '
</h1>
<form action="../redis/customer_page.php" method="post">
    <div class="container" style="background-color:#f1f1f1">
        <h1 style="text-align:center;">DASHBOARD</h1>
    </div>
    <?php  require "footer.php"?>
  </form>
</body>
</html>';
    }
    else{
        echo '<html>  
		    <head> 
				<style> 
					body{ 
					background-color:yellow; 
					padding:200px; 
					}
				</style>
			</head>
            <body><h1 style text-align:"center;">CREDENTIALS DID NOT MATCH </h1></body>
            <br>
            <p text-align:"center;"><a href="../view/login.php">CLICK HERE TO RE-LOGIN</a></p>
		</html>';
    }

?>